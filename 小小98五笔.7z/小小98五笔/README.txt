﻿
软件作者 dgod <dgod.osa@gmail.com>
对本软件的重新发布必须包含本声明
论坛 http://yong.dgod.net
软件希望能对用户有用，但软件及作者不对用户的任何使用后果负任何责任

帮助文件yong.chm		制作者是网友春意盎然，在此感谢